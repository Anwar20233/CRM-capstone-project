const psl = require('psl');

const PERSONAL_EMAIL_DOMAINS = new Set([
  'aol.com',
  'att.net',
  'btinternet.com',
  'comcast.net',
  'fastmail.com',
  'free.fr',
  'gmx.com',
  'gmx.de',
  'googlemail.com',
  'hotmail.com',
  'hotmail.fr',
  'icloud.com',
  'laposte.net',
  'live.com',
  'mac.com',
  'mail.com',
  'me.com',
  'msn.com',
  'orange.fr',
  'outlook.com',
  'outlook.fr',
  'pm.me',
  'proton.me',
  'protonmail.com',
  'sfr.fr',
  'verizon.net',
  'wanadoo.fr',
  'yahoo.co.jp',
  'yahoo.co.uk',
  'yahoo.com',
  'yandex.com',
  'yandex.ru',
  'zoho.com',
  'gmail.com',
]);

export const main = async (params) => {
  const email =
    typeof params?.primaryEmail === 'string'
      ? params.primaryEmail.trim().toLowerCase()
      : '';

  if (!email || !email.includes('@')) {
    return { isPersonal: true };
  }

  const host = email.split('@')[1] ?? '';
  const registrableDomain = host ? (psl.get(host) ?? '') : '';

  return {
    isPersonal:
      !registrableDomain ||
      PERSONAL_EMAIL_DOMAINS.has(host) ||
      PERSONAL_EMAIL_DOMAINS.has(registrableDomain),
  };
};