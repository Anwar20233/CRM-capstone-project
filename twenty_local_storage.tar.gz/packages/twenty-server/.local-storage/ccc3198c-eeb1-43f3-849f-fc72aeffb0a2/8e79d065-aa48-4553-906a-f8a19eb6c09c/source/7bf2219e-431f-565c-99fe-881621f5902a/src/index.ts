const psl = require('psl');

export const main = async (params) => {
  const email =
    typeof params?.email === 'string' ? params.email.trim().toLowerCase() : '';
  const host = email.split('@')[1] ?? '';
  const domain = host ? (psl.get(host) ?? host) : '';

  return {
    url: domain ? `https://${domain}` : '',
    domain,
  };
};