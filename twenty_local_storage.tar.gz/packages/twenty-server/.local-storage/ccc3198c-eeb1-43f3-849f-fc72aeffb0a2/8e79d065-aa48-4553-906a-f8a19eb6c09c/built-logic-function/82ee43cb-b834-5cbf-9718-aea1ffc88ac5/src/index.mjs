import { createRequire as __createRequire } from 'module';
const require = __createRequire(import.meta.url);
var __require = /* @__PURE__ */ ((x) => typeof require !== "undefined" ? require : typeof Proxy !== "undefined" ? new Proxy(x, {
  get: (a, b) => (typeof require !== "undefined" ? require : a)[b]
}) : x)(function(x) {
  if (typeof require !== "undefined") return require.apply(this, arguments);
  throw Error('Dynamic require of "' + x + '" is not supported');
});

// ../../../../../../tmp/logic-function-executor-tmpdir/lambda-build-ce8f0fe0-00cc-4a50-ba2c-53e76f4ffa86/82ee43cb-b834-5cbf-9718-aea1ffc88ac5/src/index.ts
var psl = __require("psl");
var normalizeHost = (value) => {
  if (typeof value !== "string") {
    return "";
  }
  return value.trim().toLowerCase().replace(/^https?:\/\//, "").replace(/^www\./, "").split("/")[0].split("?")[0].split("#")[0].split(":")[0];
};
var getRegistrableDomain = (value) => {
  const host = normalizeHost(value);
  if (!host) {
    return "";
  }
  return psl.get(host) ?? host;
};
var main = async (params) => {
  const domain = getRegistrableDomain(params?.domain);
  const companies = Array.isArray(params?.companies) ? params.companies : [];
  const matchingCompany = companies.find((company) => {
    const companyDomain = getRegistrableDomain(
      company?.domainName?.primaryLinkUrl
    );
    return companyDomain !== "" && companyDomain === domain;
  });
  const companyId = typeof matchingCompany?.id === "string" ? matchingCompany.id : "";
  return {
    companyId,
    hasMatch: companyId !== ""
  };
};
export {
  main
};
//# sourceMappingURL=index.mjs.map
