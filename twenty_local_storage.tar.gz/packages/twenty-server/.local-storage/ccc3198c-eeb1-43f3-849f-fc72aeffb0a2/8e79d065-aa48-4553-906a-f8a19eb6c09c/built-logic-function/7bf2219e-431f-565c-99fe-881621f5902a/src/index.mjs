import { createRequire as __createRequire } from 'module';
const require = __createRequire(import.meta.url);
var __require = /* @__PURE__ */ ((x) => typeof require !== "undefined" ? require : typeof Proxy !== "undefined" ? new Proxy(x, {
  get: (a, b) => (typeof require !== "undefined" ? require : a)[b]
}) : x)(function(x) {
  if (typeof require !== "undefined") return require.apply(this, arguments);
  throw Error('Dynamic require of "' + x + '" is not supported');
});

// ../../../../../../tmp/logic-function-executor-tmpdir/lambda-build-6382bfd8-2816-46e3-8a9c-e9b9ae29bfda/7bf2219e-431f-565c-99fe-881621f5902a/src/index.ts
var psl = __require("psl");
var main = async (params) => {
  const email = typeof params?.email === "string" ? params.email.trim().toLowerCase() : "";
  const host = email.split("@")[1] ?? "";
  const domain = host ? psl.get(host) ?? host : "";
  return {
    url: domain ? `https://${domain}` : "",
    domain
  };
};
export {
  main
};
//# sourceMappingURL=index.mjs.map
