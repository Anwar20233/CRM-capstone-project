import { createRequire as __createRequire } from 'module';
const require = __createRequire(import.meta.url);
var __require = /* @__PURE__ */ ((x) => typeof require !== "undefined" ? require : typeof Proxy !== "undefined" ? new Proxy(x, {
  get: (a, b) => (typeof require !== "undefined" ? require : a)[b]
}) : x)(function(x) {
  if (typeof require !== "undefined") return require.apply(this, arguments);
  throw Error('Dynamic require of "' + x + '" is not supported');
});

// ../../../../../../tmp/logic-function-executor-tmpdir/lambda-build-1fbb85ed-ef86-4a2a-9376-4ed1c7c4df95/dc00f652-41ae-5649-8f8d-c3a804a241f7/src/index.ts
var psl = __require("psl");
var PERSONAL_EMAIL_DOMAINS = /* @__PURE__ */ new Set([
  "aol.com",
  "att.net",
  "btinternet.com",
  "comcast.net",
  "fastmail.com",
  "free.fr",
  "gmx.com",
  "gmx.de",
  "googlemail.com",
  "hotmail.com",
  "hotmail.fr",
  "icloud.com",
  "laposte.net",
  "live.com",
  "mac.com",
  "mail.com",
  "me.com",
  "msn.com",
  "orange.fr",
  "outlook.com",
  "outlook.fr",
  "pm.me",
  "proton.me",
  "protonmail.com",
  "sfr.fr",
  "verizon.net",
  "wanadoo.fr",
  "yahoo.co.jp",
  "yahoo.co.uk",
  "yahoo.com",
  "yandex.com",
  "yandex.ru",
  "zoho.com",
  "gmail.com"
]);
var main = async (params) => {
  const email = typeof params?.primaryEmail === "string" ? params.primaryEmail.trim().toLowerCase() : "";
  if (!email || !email.includes("@")) {
    return { isPersonal: true };
  }
  const host = email.split("@")[1] ?? "";
  const registrableDomain = host ? psl.get(host) ?? "" : "";
  return {
    isPersonal: !registrableDomain || PERSONAL_EMAIL_DOMAINS.has(host) || PERSONAL_EMAIL_DOMAINS.has(registrableDomain)
  };
};
export {
  main
};
//# sourceMappingURL=index.mjs.map
